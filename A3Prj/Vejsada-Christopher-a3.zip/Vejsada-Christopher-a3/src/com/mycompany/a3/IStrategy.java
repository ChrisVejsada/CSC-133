package com.mycompany.a3;

public interface IStrategy {
	public void setStrategy();
	public void invokeStrategy();
}