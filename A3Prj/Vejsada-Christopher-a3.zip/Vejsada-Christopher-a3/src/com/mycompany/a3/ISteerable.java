package com.mycompany.a3;

public interface ISteerable {
	
	/**
	 * Allows the object to be steered
	 * @param changeHeading
	 */
	void changeHeading(char s);

}
