package com.mycompany.a1;

public interface ISteerable {
	
	/**
	 * Allows the object to be steered
	 * @param changeHeading
	 */
	void changeHeading(char s);

}
