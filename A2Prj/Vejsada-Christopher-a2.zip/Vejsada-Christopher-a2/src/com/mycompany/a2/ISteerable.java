package com.mycompany.a2;

public interface ISteerable {
	
	/**
	 * Allows the object to be steered
	 * @param changeHeading
	 */
	void changeHeading(char s);

}
