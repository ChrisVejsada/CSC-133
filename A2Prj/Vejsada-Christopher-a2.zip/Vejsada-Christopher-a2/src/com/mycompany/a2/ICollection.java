package com.mycompany.a2;

public interface ICollection {
	
	public void add(Object object);
	
	public IIterator getIterator();
	

}
